using System;

namespace Server.Items
{
	public abstract class BaseHat : BaseClothing
	{
		public BaseHat( int itemID ) : this( itemID, 0 )
		{
		}

		public BaseHat( int itemID, int hue ) : base( itemID, Layer.Helm, hue )
		{
		}

		public BaseHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	[Flipable( 0x2305, 0x2306 )]
	public class FlowerGarland : BaseHat
	{
		public override int PhysicalResistance{ get{ return 3; } }
		public override int FireResistance{ get{ return 3; } }
		public override int ColdResistance{ get{ return 6; } }
		public override int PoisonResistance{ get{ return 9; } }
		public override int EnergyResistance{ get{ return 9; } }

		[Constructable]
		public FlowerGarland() : this( 0 )
		{
		}

		[Constructable]
		public FlowerGarland( int hue ) : base( 0x2305, hue )
		{
			Weight = 1.0;
		}

		public FlowerGarland( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class FloppyHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public FloppyHat() : this( 0 )
		{
		}

		[Constructable]
		public FloppyHat( int hue ) : base( 0x1713, hue )
		{
			Weight = 1.0;
		}

		public FloppyHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class WideBrimHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public WideBrimHat() : this( 0 )
		{
		}

		[Constructable]
		public WideBrimHat( int hue ) : base( 0x1714, hue )
		{
			Weight = 1.0;
		}

		public WideBrimHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Cap : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public Cap() : this( 0 )
		{
		}

		[Constructable]
		public Cap( int hue ) : base( 0x1715, hue )
		{
			Weight = 1.0;
		}

		public Cap( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class SkullCap : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 3; } }
		public override int ColdResistance{ get{ return 5; } }
		public override int PoisonResistance{ get{ return 8; } }
		public override int EnergyResistance{ get{ return 8; } }

		[Constructable]
		public SkullCap() : this( 0 )
		{
		}

		[Constructable]
		public SkullCap( int hue ) : base( 0x1544, hue )
		{
			Weight = 1.0;
		}

		public SkullCap( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Bandana : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 3; } }
		public override int ColdResistance{ get{ return 5; } }
		public override int PoisonResistance{ get{ return 8; } }
		public override int EnergyResistance{ get{ return 8; } }

		[Constructable]
		public Bandana() : this( 0 )
		{
		}

		[Constructable]
		public Bandana( int hue ) : base( 0x1540, hue )
		{
			Weight = 1.0;
		}

		public Bandana( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class TallStrawHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public TallStrawHat() : this( 0 )
		{
		}

		[Constructable]
		public TallStrawHat( int hue ) : base( 0x1716, hue )
		{
			Weight = 1.0;
		}

		public TallStrawHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class StrawHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public StrawHat() : this( 0 )
		{
		}

		[Constructable]
		public StrawHat( int hue ) : base( 0x1717, hue )
		{
			Weight = 1.0;
		}

		public StrawHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class OrcishKinMask : BaseHat
	{
		public override int PhysicalResistance{ get{ return 1; } }
		public override int FireResistance{ get{ return 1; } }
		public override int ColdResistance{ get{ return 7; } }
		public override int PoisonResistance{ get{ return 7; } }
		public override int EnergyResistance{ get{ return 8; } }

		public override bool Dye( Mobile from, DyeTub sender )
		{
			from.SendLocalizedMessage( sender.FailMessage );
			return false;
		}

		[Constructable]
		public OrcishKinMask() : this( 0x8A4 )
		{
		}

		[Constructable]
		public OrcishKinMask( int hue ) : base( 0x141B, hue )
		{
			Weight = 2.0;
			Name = "a mask of orcish kin";
		}

		public override bool CanEquip( Mobile m )
		{
			if ( !base.CanEquip( m ) )
				return false;

			if ( m.BodyMod == 183 || m.BodyMod == 184 )
			{
				m.SendLocalizedMessage( 1061629 ); // You can't do that while wearing savage kin paint.
				return false;
			}

			return true;
		}

		public override void OnAdded( object parent )
		{
			base.OnAdded( parent );

			//if ( parent is Mobile )
			//	Misc.Titles.AwardKarma( (Mobile)parent, -20, true );
		}

		public OrcishKinMask( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			if ( Hue != 0x8A4 )
				Hue = 0x8A4;
		}
	}

	public class SavageMask : BaseHat
	{
		public override int PhysicalResistance{ get{ return 3; } }
		public override int FireResistance{ get{ return 0; } }
		public override int ColdResistance{ get{ return 6; } }
		public override int PoisonResistance{ get{ return 10; } }
		public override int EnergyResistance{ get{ return 5; } }

		public static int GetRandomHue()
		{
			int v = Utility.RandomBirdHue();

			if ( v == 2101 )
				v = 0;

			return v;
		}

		public override bool Dye( Mobile from, DyeTub sender )
		{
			from.SendLocalizedMessage( sender.FailMessage );
			return false;
		}

		[Constructable]
		public SavageMask() : this( GetRandomHue() )
		{
		}

		[Constructable]
		public SavageMask( int hue ) : base( 0x154B, hue )
		{
			Weight = 2.0;
		}

		public SavageMask( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			if ( Hue != 0 && (Hue < 2101 || Hue > 2130) )
				Hue = GetRandomHue();
		}
	}

	public class WizardsHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public WizardsHat() : this( 0 )
		{
		}

		[Constructable]
		public WizardsHat( int hue ) : base( 0x1718, hue )
		{
			Weight = 1.0;
		}

		public WizardsHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class MagicWizardsHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		public override int LabelNumber{ get{ return 1041072; } } // a magical wizard's hat

		#region Stat Mods
		public void AddStatMods( Mobile m )
		{
			if ( m == null )
				return;

			string modName = this.Serial.ToString();

			StatMod strMod = new StatMod( StatType.Str, String.Format( "[Magic Hat] -Str {0}", modName ), -5, TimeSpan.Zero );
			StatMod dexMod = new StatMod( StatType.Dex, String.Format( "[Magic Hat] -Dex {0}", modName ), -5, TimeSpan.Zero );
			StatMod intMod = new StatMod( StatType.Int, String.Format( "[Magic Hat] +Int {0}", modName ), +5, TimeSpan.Zero );

			m.AddStatMod( strMod );
			m.AddStatMod( dexMod );
			m.AddStatMod( intMod );
		}

		public void RemoveStatMods( Mobile m )
		{
			if ( m == null )
				return;

			string modName = this.Serial.ToString();

			m.RemoveStatMod( String.Format( "[Magic Hat] -Str {0}", modName ) );
			m.RemoveStatMod( String.Format( "[Magic Hat] -Dex {0}", modName ) );
			m.RemoveStatMod( String.Format( "[Magic Hat] +Int {0}", modName ) );
		}

		public override void OnAdded( object parent )
		{
			base.OnAdded( parent );
			AddStatMods( parent as Mobile );
		}

		public override void OnRemoved( object parent )
		{
			base.OnRemoved( parent );
			RemoveStatMods( parent as Mobile );
		}
		#endregion

		[Constructable]
		public MagicWizardsHat() : this( 0 )
		{
		}

		[Constructable]
		public MagicWizardsHat( int hue ) : base( 0x1718, hue )
		{
			Weight = 1.0;
		}

		public MagicWizardsHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			AddStatMods( Parent as Mobile );
		}
	}

	public class Bonnet : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public Bonnet() : this( 0 )
		{
		}

		[Constructable]
		public Bonnet( int hue ) : base( 0x1719, hue )
		{
			Weight = 1.0;
		}

		public Bonnet( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class FeatheredHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public FeatheredHat() : this( 0 )
		{
		}

		[Constructable]
		public FeatheredHat( int hue ) : base( 0x171A, hue )
		{
			Weight = 1.0;
		}

		public FeatheredHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class TricorneHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public TricorneHat() : this( 0 )
		{
		}

		[Constructable]
		public TricorneHat( int hue ) : base( 0x171B, hue )
		{
			Weight = 1.0;
		}

		public TricorneHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class JesterHat : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 5; } }
		public override int ColdResistance{ get{ return 9; } }
		public override int PoisonResistance{ get{ return 5; } }
		public override int EnergyResistance{ get{ return 5; } }

		[Constructable]
		public JesterHat() : this( 0 )
		{
		}

		[Constructable]
		public JesterHat( int hue ) : base( 0x171C, hue )
		{
			Weight = 1.0;
		}

		public JesterHat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class BearMask : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 3; } }
		public override int ColdResistance{ get{ return 5; } }
		public override int PoisonResistance{ get{ return 8; } }
		public override int EnergyResistance{ get{ return 8; } }

		public override bool Dye( Mobile from, DyeTub sender )
		{
			return false;
		}

		[Constructable]
		public BearMask() : this( 0 )
		{
		}

		[Constructable]
		public BearMask( int hue ) : base( 0x1545, hue )
		{
			Weight = 1.0;
		}

		public BearMask( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class DeerMask : BaseHat
	{
		public override int PhysicalResistance{ get{ return 0; } }
		public override int FireResistance{ get{ return 3; } }
		public override int ColdResistance{ get{ return 5; } }
		public override int PoisonResistance{ get{ return 8; } }
		public override int EnergyResistance{ get{ return 8; } }

		public override bool Dye( Mobile from, DyeTub sender )
		{
			return false;
		}

		[Constructable]
		public DeerMask() : this( 0 )
		{
		}

		[Constructable]
		public DeerMask( int hue ) : base( 0x1547, hue )
		{
			Weight = 1.0;
		}

		public DeerMask( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}