using System;

namespace Server.Items
{
	public abstract class Beard : BaseItem
	{
		public Beard( int itemID ) : this( itemID, 0 )
		{
		}

		public Beard( int itemID, int hue ) : base( itemID )
		{
			LootType = LootType.Blessed;
			Layer = Layer.FacialHair;
			Hue = hue;
		}

		public Beard( Serial serial ) : base( serial )
		{
		}

		public override bool DisplayLootType{ get{ return false; } }

		public override bool VerifyMove( Mobile from )
		{
			return ( from.AccessLevel >= AccessLevel.GameMaster );
		}

		public override DeathMoveResult OnParentDeath( Mobile parent )
		{
			Dupe( Amount );

			return DeathMoveResult.MoveToCorpse;
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			LootType = LootType.Blessed;

			int version = reader.ReadInt();
		}
	}

	public class GenericBeard : Beard
	{
		[Constructable]
		public GenericBeard( int itemID ) : this( itemID, 0 )
		{
		}

		[Constructable]
		public GenericBeard( int itemID, int hue ) : base( itemID, hue )
		{
		}

		public GenericBeard( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new GenericBeard( ItemID, Hue ), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class LongBeard : Beard
	{
		[Constructable]
		public LongBeard() : this( 0 )
		{
		}

		[Constructable]
		public LongBeard( int hue ) : base( 0x203E, hue )
		{
		}

		public LongBeard( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new LongBeard(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ShortBeard : Beard
	{
		[Constructable]
		public ShortBeard() : this( 0 )
		{
		}

		[Constructable]
		public ShortBeard( int hue ) : base( 0x203f, hue )
		{
		}

		public ShortBeard( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new ShortBeard(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Goatee : Beard
	{
		[Constructable]
		public Goatee() : this( 0 )
		{
		}

		[Constructable]
		public Goatee( int hue ) : base( 0x2040, hue )
		{
		}

		public Goatee( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new Goatee(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Mustache : Beard
	{
		[Constructable]
		public Mustache() : this( 0 )
		{
		}

		[Constructable]
		public Mustache( int hue ) : base( 0x2041, hue )
		{
		}

		public Mustache( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new Mustache(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class MediumShortBeard : Beard
	{
		[Constructable]
		public MediumShortBeard() : this( 0 )
		{
		}

		[Constructable]
		public MediumShortBeard( int hue ) : base( 0x204B, hue )
		{
		}

		public MediumShortBeard( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new MediumShortBeard(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class MediumLongBeard : Beard
	{
		[Constructable]
		public MediumLongBeard() : this( 0 )
		{
		}

		[Constructable]
		public MediumLongBeard( int hue ) : base( 0x204C, hue )
		{
		}

		public MediumLongBeard( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new MediumLongBeard(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class Vandyke : Beard
	{
		[Constructable]
		public Vandyke() : this( 0 )
		{
		}

		[Constructable]
		public Vandyke( int hue ) : base( 0x204D, hue )
		{
		}

		public Vandyke( Serial serial ) : base( serial )
		{
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new Vandyke(), amount );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}